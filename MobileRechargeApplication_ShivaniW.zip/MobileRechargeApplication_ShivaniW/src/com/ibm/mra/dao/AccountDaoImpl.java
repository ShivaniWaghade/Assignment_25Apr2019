package com.ibm.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.ibm.mra.beans.Account;


public class AccountDaoImpl 
{
	
	private Map<String,Account> accountEntry=new 
			HashMap<String,Account>();
//	private Map<String,Account> employee=new 
//			HashMap<String, Account>();
	int i = 0;
	
	{
		accountEntry.put("9822201650",new Account("Prepaid","Tejaswini",450,"9822201650"));
		accountEntry.put("9822206157",new Account("Prepaid","Shivani",1000,"9822206157"));
		accountEntry.put("8329509589",new Account("Postpaid","Nikhil",600,"8329509589"));
		accountEntry.put("7030427425",new Account("Postpaid","Pooja",750,"7030427425"));	
	}

	

	public Account chkMobileNumber(String mobile) {
		for (String  m : accountEntry.keySet()) 
		{
			//System.out.println(m);
			if(m.equals(mobile))
			{
				return accountEntry.get(m);
			}
			
		}
		return null;
	
	}



	public Account getAccountDetails(Account acc) 
	{
		return acc;
		
	}



	public double rechargeAccount(String mobile1, double amount) {
		double recharge=0;
		for(String m : accountEntry.keySet())
		{
			if(m.equals(mobile1))
			{
				Account acc = accountEntry.get(m);
				recharge= amount+acc.getAccountBalance();
				return recharge;
			}
				
		}
		return 0;
	}
	
}
