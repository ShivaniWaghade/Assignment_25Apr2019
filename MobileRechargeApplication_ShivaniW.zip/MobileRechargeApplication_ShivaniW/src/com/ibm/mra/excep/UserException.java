package com.ibm.mra.excep;

public class UserException extends Exception 
{
	public UserException(String str)
	{
		super(str);
	}
}
