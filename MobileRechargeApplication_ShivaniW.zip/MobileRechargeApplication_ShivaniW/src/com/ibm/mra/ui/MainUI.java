package com.ibm.mra.ui;

import java.util.Scanner;

import com.ibm.mra.beans.Account;
import com.ibm.mra.service.AccountServiceImpl;

public class MainUI 
{
	
	public static void main(String[] args) {
		AccountServiceImpl service = new AccountServiceImpl();
		int flag = 0;
		do {
		System.out.println("Select option:\n1.Account Balance Enquiry\n2.Recharge Account\n3.Exit");
		Scanner scan = new Scanner(System.in);
		int option = scan.nextInt();
		scan.nextLine();
		
		switch(option)
		{
		case 1:System.out.println("Enter Mobile Number");
		       String mobile = scan.nextLine();
		       service.getAccountDetails(mobile);
		       break;
		case 2:System.out.println("Enter Mobile Number");
				String mobile1 = scan.nextLine();
				System.out.println("Enter Recharge Amount");
				double amount = scan.nextDouble();
				double recharge= service.rechargeAccount(mobile1,amount);
				System.out.println("Balance after recharge: "+recharge);
				break;
				
		case 3:flag=1;
				break;
				
		default: System.out.println("Invalid code");
		
		}
		}while(flag==0);
	}
}
