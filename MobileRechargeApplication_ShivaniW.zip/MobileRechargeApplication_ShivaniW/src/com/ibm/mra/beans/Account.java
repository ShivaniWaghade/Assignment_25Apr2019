package com.ibm.mra.beans;

public class Account 
{
	
	private String accountType;
	private String customerName;
	private double accountBalance;
	private String mobileNo;
	private double rechargeAmount;
	public Account()
	{
		
	}
	public Account(String accountType, String customerName, double accountBalance, String mobile)
	{
		this.accountType = accountType;
		this.customerName = customerName;
		this.accountBalance = accountBalance;
		this.mobileNo = mobileNo;
		
	}
	
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getRechargeAmount() {
		return rechargeAmount;
	}
	public void setRechargeAmount(double rechargeAmount) {
		this.rechargeAmount = rechargeAmount;
	}
	
	@Override
	public String toString() {
		return "Balance "+accountBalance;
	}	
	}
	
