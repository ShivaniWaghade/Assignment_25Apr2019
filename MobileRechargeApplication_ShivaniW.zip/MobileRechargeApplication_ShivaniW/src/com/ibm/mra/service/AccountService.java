package com.ibm.mra.service;

public interface AccountService {

}
