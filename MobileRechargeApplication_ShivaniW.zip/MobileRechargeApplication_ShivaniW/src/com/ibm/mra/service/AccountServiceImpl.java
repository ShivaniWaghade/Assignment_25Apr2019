package com.ibm.mra.service;

import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.AccountDaoImpl;

public class AccountServiceImpl {
	AccountDaoImpl dao = new AccountDaoImpl();

	public void getAccountDetails(String mobile) 
	{
		Account acc = dao.chkMobileNumber(mobile);
		
		if(acc==null)
		{
			System.out.println("mobile number doesn't exist");	
		}
		else
		{
			System.out.println(dao.getAccountDetails(acc));
			
		}
		
		
	}

	public double rechargeAccount(String mobile1, double amount) 
	{
		Account acc = dao.chkMobileNumber(mobile1);
		if(acc==null)
		{
			System.out.println("number doesn't exist");
		}
		else
		{
			return dao.rechargeAccount(mobile1,amount);
		}
		return amount;
	}

}
